package com.klaswenz;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Simple JSON config stored at .minecraft/config/klaswenz.json */
public class KlaswenzConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static KlaswenzConfig INSTANCE = new KlaswenzConfig();

    public boolean enabled = true;
    public boolean keyboard = true;
    public boolean mouse = true;
    public boolean releaseSounds = true;
    /** creamy, tok, ince or klik */
    public String profile = "creamy";
    /** 0.0 - 1.0 */
    public float volume = 0.6f;
    /** Pitch multiplier: lower = deeper, higher = thinner. 0.6 - 1.5 */
    public float pitch = 1.0f;
    /** Random pitch variation (0.0 = none). */
    public float pitchVariation = 0.06f;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("klaswenz.json");
    }

    public static void load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                KlaswenzConfig loaded = GSON.fromJson(r, KlaswenzConfig.class);
                if (loaded != null) {
                    INSTANCE = loaded;
                }
            } catch (Exception e) {
                System.err.println("[Klaswenz] Could not read config, using defaults: " + e);
            }
        }
        sanitize();
        save();
    }

    public static void sanitize() {
        KlaswenzConfig c = INSTANCE;
        c.volume = Math.max(0.0f, Math.min(1.0f, c.volume));
        c.pitch = Math.max(0.6f, Math.min(1.5f, c.pitch));
        c.pitchVariation = Math.max(0.0f, Math.min(0.5f, c.pitchVariation));
        if (c.profile == null) c.profile = "creamy";
    }

    public static void save() {
        try {
            Path p = path();
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(p)) {
                GSON.toJson(INSTANCE, w);
            }
        } catch (IOException e) {
            System.err.println("[Klaswenz] Could not save config: " + e);
        }
    }
}
