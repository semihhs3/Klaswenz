package com.klaswenz;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Simple, touch-friendly settings menu (vanilla buttons only). */
public class KlaswenzScreen extends Screen {
    private final Screen parent;

    private ButtonWidget modBtn;
    private ButtonWidget keyboardBtn;
    private ButtonWidget mouseBtn;
    private ButtonWidget releaseBtn;
    private ButtonWidget profileBtn;

    private int top;
    private int volumeY;
    private int pitchY;

    public KlaswenzScreen(Screen parent) {
        super(Text.translatable("klaswenz.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        KlaswenzConfig c = KlaswenzConfig.INSTANCE;
        int cx = this.width / 2;
        top = Math.max(26, this.height / 2 - 78);

        // row 0: mod on/off | keyboard on/off
        modBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.enabled = !c.enabled;
            changed(true);
        }).dimensions(cx - 102, top, 100, 20).build());
        keyboardBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.keyboard = !c.keyboard;
            changed(true);
        }).dimensions(cx + 2, top, 100, 20).build());

        // row 1: mouse on/off | release sound on/off
        mouseBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.mouse = !c.mouse;
            changed(false);
        }).dimensions(cx - 102, top + 24, 100, 20).build());
        releaseBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.releaseSounds = !c.releaseSounds;
            changed(false);
        }).dimensions(cx + 2, top + 24, 100, 20).build());

        // row 2: sound type (cycles Creamy -> Tok -> Ince -> Klik)
        profileBtn = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            c.profile = SoundProfile.byId(c.profile).next().id;
            changed(true);
        }).dimensions(cx - 102, top + 48, 204, 20).build());

        // row 3: volume - / +
        volumeY = top + 72;
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
            c.volume = Math.round((c.volume - 0.1f) * 10f) / 10f;
            changed(true);
        }).dimensions(cx - 102, volumeY, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
            c.volume = Math.round((c.volume + 0.1f) * 10f) / 10f;
            changed(true);
        }).dimensions(cx + 72, volumeY, 30, 20).build());

        // row 4: pitch - / +   (lower = deeper "tok", higher = thinner "ince")
        pitchY = top + 96;
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
            c.pitch = Math.round((c.pitch - 0.05f) * 100f) / 100f;
            changed(true);
        }).dimensions(cx - 102, pitchY, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
            c.pitch = Math.round((c.pitch + 0.05f) * 100f) / 100f;
            changed(true);
        }).dimensions(cx + 72, pitchY, 30, 20).build());

        // done
        addDrawableChild(ButtonWidget.builder(Text.translatable("klaswenz.done"), b -> close())
                .dimensions(cx - 102, top + 134, 204, 20).build());

        refresh();
    }

    private void changed(boolean preview) {
        KlaswenzConfig.sanitize();
        KlaswenzConfig.save();
        refresh();
        if (preview) {
            KlaswenzClient.playPreview();
        }
    }

    private void refresh() {
        KlaswenzConfig c = KlaswenzConfig.INSTANCE;
        modBtn.setMessage(Text.translatable("klaswenz.mod", state(c.enabled)));
        keyboardBtn.setMessage(Text.translatable("klaswenz.keyboard", state(c.keyboard)));
        mouseBtn.setMessage(Text.translatable("klaswenz.mouse", state(c.mouse)));
        releaseBtn.setMessage(Text.translatable("klaswenz.release", state(c.releaseSounds)));
        profileBtn.setMessage(Text.translatable("klaswenz.profile", SoundProfile.byId(c.profile).displayName()));
    }

    private static Text state(boolean on) {
        return on
                ? Text.translatable("klaswenz.on").formatted(Formatting.GREEN)
                : Text.translatable("klaswenz.off").formatted(Formatting.RED);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        KlaswenzConfig c = KlaswenzConfig.INSTANCE;
        int cx = this.width / 2;

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, top - 16, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.translatable("klaswenz.volume", Math.round(c.volume * 100) + "%"),
                cx, volumeY + 6, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.translatable("klaswenz.pitch", String.format("%.2f", c.pitch)),
                cx, pitchY + 6, 0xFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.translatable("klaswenz.pitch.hint"),
                cx, pitchY + 23, 0xAAAAAA);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (KlaswenzClient.openKey != null && KlaswenzClient.openKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        KlaswenzConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
