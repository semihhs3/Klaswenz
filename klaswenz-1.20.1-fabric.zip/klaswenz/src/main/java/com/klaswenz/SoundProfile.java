package com.klaswenz;

import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Keyboard sound sets. Files live in assets/klaswenz/sounds/<id>/ */
public enum SoundProfile {
    CREAMY("creamy"),
    TOK("tok"),
    INCE("ince"),
    KLIK("klik");

    public final String id;
    public final SoundEvent down;
    public final SoundEvent up;

    SoundProfile(String id) {
        this.id = id;
        this.down = SoundEvent.of(new Identifier("klaswenz", "key_down_" + id));
        this.up = SoundEvent.of(new Identifier("klaswenz", "key_up_" + id));
    }

    public SoundProfile next() {
        SoundProfile[] all = values();
        return all[(ordinal() + 1) % all.length];
    }

    public Text displayName() {
        return Text.translatable("klaswenz.profile." + id);
    }

    public static SoundProfile byId(String id) {
        for (SoundProfile p : values()) {
            if (p.id.equals(id)) return p;
        }
        return CREAMY;
    }
}
