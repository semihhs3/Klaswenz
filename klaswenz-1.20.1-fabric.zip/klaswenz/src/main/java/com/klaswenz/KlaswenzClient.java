package com.klaswenz;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class KlaswenzClient implements ClientModInitializer {
    public static final String MOD_ID = "klaswenz";

    public static final SoundEvent MOUSE_DOWN = SoundEvent.of(new Identifier(MOD_ID, "mouse_down"));
    public static final SoundEvent MOUSE_UP = SoundEvent.of(new Identifier(MOD_ID, "mouse_up"));

    private static final Random RANDOM = new Random();
    public static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        KlaswenzConfig.load();

        // K opens the settings menu
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.klaswenz.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                "key.categories.klaswenz"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new KlaswenzScreen(null));
                }
            }
        });

        // Touch-friendly entry for PojavLauncher: a "Klaswenz" button in the
        // top-left corner of the title screen and the pause menu.
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen || screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.translatable("klaswenz.open"),
                                        b -> client.setScreen(new KlaswenzScreen(screen)))
                                .dimensions(6, 6, 80, 20)
                                .build());
            }
        });
    }

    /** Called from KeyboardMixin. action: 0 = release, 1 = press, 2 = repeat. */
    public static void onKeyEvent(long window, int key, int action) {
        KlaswenzConfig c = KlaswenzConfig.INSTANCE;
        if (!c.enabled || !c.keyboard || key == GLFW.GLFW_KEY_UNKNOWN) return;
        SoundProfile profile = SoundProfile.byId(c.profile);
        if (action == GLFW.GLFW_PRESS) {
            play(profile.down, 1.0f);
        } else if (action == GLFW.GLFW_RELEASE && c.releaseSounds) {
            play(profile.up, 0.8f);
        }
    }

    /** Called from MouseMixin. action: 0 = release, 1 = press. */
    public static void onMouseEvent(long window, int button, int action) {
        KlaswenzConfig c = KlaswenzConfig.INSTANCE;
        if (!c.enabled || !c.mouse) return;
        if (action == GLFW.GLFW_PRESS) {
            play(MOUSE_DOWN, 1.0f);
        } else if (action == GLFW.GLFW_RELEASE && c.releaseSounds) {
            play(MOUSE_UP, 0.8f);
        }
    }

    /** Plays the current profile's key sound, used by the menu. */
    public static void playPreview() {
        play(SoundProfile.byId(KlaswenzConfig.INSTANCE.profile).down, 1.0f);
    }

    private static void play(SoundEvent event, float volumeMultiplier) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.getSoundManager() == null) return;
            KlaswenzConfig c = KlaswenzConfig.INSTANCE;
            float variation = (RANDOM.nextFloat() * 2.0f - 1.0f) * c.pitchVariation;
            float pitch = c.pitch * (1.0f + variation);
            mc.getSoundManager().play(PositionedSoundInstance.master(event, pitch, c.volume * volumeMultiplier));
        } catch (Throwable ignored) {
            // never let a sound problem crash input handling
        }
    }
}
