package com.klaswenz.mixin;

import com.klaswenz.KlaswenzClient;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public class MouseMixin {
    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void klaswenz$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        KlaswenzClient.onMouseEvent(window, button, action);
    }
}
