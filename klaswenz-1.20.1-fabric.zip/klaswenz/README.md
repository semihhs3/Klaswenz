# Klaswenz

Client-side Fabric mod for **Minecraft 1.20.1** that plays creamy mechanical keyboard
and mouse click sounds. Works in PojavLauncher (Java 17).

Requires: Fabric Loader >= 0.14.21 and Fabric API.

## Menu
Press **K** (or tap the **Klaswenz** button in the top-left of the title / pause screen).
- Mod / Keyboard / Mouse / Release sound on-off
- Sound type: Creamy, Tok (deep), Ince (thin), Klik (clicky)
- Volume - / +  and Pitch - / + (lower = deeper, higher = thinner)

## Build (GitHub Actions)
Push to GitHub -> Actions -> "build" -> download the artifact (`klaswenz-1.1.0.jar`) -> `mods` folder.

## Config
`.minecraft/config/klaswenz.json` is edited automatically by the menu.

## Custom sounds
Override files in `assets/klaswenz/sounds/<profile>/` (mono .ogg) with a resource pack.
